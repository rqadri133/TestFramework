﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Reflection;

namespace TestFrameworkConnectionService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
   [ServiceBehavior( ConcurrencyMode = ConcurrencyMode.Multiple )]   
    public class TestConnectionService : ITestConnectionService
    {

        public List<Assembly> LoadAllAssembliesForTheConnections<T>(List<T> node)
        {
            List<Assembly> allAssemblies = null;

            try
            {


            }
            catch(Exception excp)
            {



            }
            finally
            {


                
            }
            return allAssemblies;

        }





        public List<Connector> ConnectService<T>(List<T> node)
        {

            List<Connector> nodes = new List<Connector>();
            try
            {


            }
            catch(Exception excp)
            {


            }
            finally
            {



            }

            return nodes; 

        }

        




    }
}
