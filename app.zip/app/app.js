﻿
'use strict';


var app;
(function () {

    app = angular.module("TFApp", ['ng', 'ngMaterial', 'ngMessages']).run(function ($rootScope) {
        $rootScope.IsLogin = false;
        
        $rootScope.parentObj = {};
        $rootScope.parentObj.afterLogin = false;
        $rootScope.parentObj.beforeLogin = true;
        $rootScope.users = [];

    });





}

        )();


