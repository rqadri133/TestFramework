﻿

app.controller('TFController', function ($scope, $http, $rootScope, TestFramworkService) {






});



app.controller('LoginController', function ($scope, $http, $rootScope, TestFramworkService) {

    $scope.login = function () {

       /* test the screen only */
        var userInfo = {
            UserName: $scope.txtUserID,
            Pwd: $scope.txtPwd

        };



        var userinformation = TestFramworkService.loginInfo(userInfo);

        userinformation.then(function (d) {

            $rootScope.parentObj.beforeLogin = false;

            $rootScope.parentObj.afterLogin = true;

            $rootScope.users = d.data.AllUsers;

        }, function (error) {
            console.log('Oops! Something went wrong while saving the data.')
        });
    };


    


});



app.controller('TestCaseController', function ($scope, $http, $rootScope, TestFramworkService) {

    $scope.testCycleDate = null;


    $scope.addTestCase = function () {

        /* test the screen only */
        var testcaseInfo = {
            TestCaseName: $scope.txtTestCaseName,
            TestCaseDate : $scope.testCycleDate ,  
            UserID  : $scope.tokenID 
        };

        var testcaseinformation = TestFramworkService.saveTestCaseInfo(testcaseInfo);

        testcaseinformation.then(function (d) {

            $rootScope.parentObj.beforeLogin = false;

            $rootScope.parentObj.afterLogin = true;

        }, function (error) {
            console.log('Oops! Something went wrong while saving the data.')
        });
    };





});




app.controller('DemoController', function ($scope, $http, $rootScope, TestFramworkService) {


    $scope.addUserInformation = function () {

        var userInfo = {
            LoginName: $scope.loginName,
            PasswordHash: $scope.txtPwd,
            EmailAddress: $scope.emailAddress,
            PhoneNumber: $scope.phoneNumber,
            FirstName: $scope.firstName,
            LastName: $scope.lastName,
            CompanyName: $scope.companyName,
            CompanyWebSite: $scope.companyWebsite

        };



        var userinformation = TestFramworkService.saveUser(userInfo);


        userinformation.then(function (d) {

               

        }, function (error) {
            console.log('Oops! Something went wrong while saving the data.')
        })
    };

});