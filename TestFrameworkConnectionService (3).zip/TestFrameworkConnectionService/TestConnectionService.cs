﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Reflection;
using TestFrameworkConnectionService.Connection;

namespace TestFrameworkConnectionService
{


    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
   [ServiceBehavior( ConcurrencyMode = ConcurrencyMode.Multiple )]   
    public class TestConnectionService : ITestConnectionService
    {
        // The Assembliess will be loaded to prvide the connections for any particular ConnectionType
        public List<Assembly> LoadAllAssembliesForTheConnections<T>(List<T> node)
        {
            List<Assembly> allAssemblies = null;
            try
            {


            }
            catch(Exception excp)
            {



            }
            finally
            {


                
            }
            return allAssemblies;

        }





        public List<Connector> ConnectService<T>(List<T> node)
        {

            List<Connector> nodes = new List<Connector>();
            try
            {


            }
            catch(Exception excp)
            {


            }
            finally
            {



            }

            return nodes; 

        }

        

        
        public IConnection ConnectDirect<T>(T node , Guid Id)
        {
            if(node.GetType().IsClass)
            {
                // Is Register Authorized  for this Application this Class Type look in AutorizedConnectionClassName 
                // IS this Assembly is autorize for Access 
            } 

           
        }






    }
}
